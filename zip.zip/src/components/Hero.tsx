import { motion } from 'motion/react';
import { Download, ChevronDown, MapPin, Mail, Linkedin } from 'lucide-react';

export default function Hero() {
  return (
    <section className="w-full min-h-[80vh] flex flex-col justify-center items-start pt-12">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.2 }}
      >
        <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
          Siddharth Sharma
        </h1>
        <h2 className="text-xl md:text-2xl text-sky-400 font-medium mb-6 max-w-2xl leading-relaxed">
          Technical Product Manager | Project Manager | Data Analytics
        </h2>
        <div className="flex flex-col md:flex-row gap-4 text-slate-400 mb-10">
          <span className="flex items-center gap-2"><MapPin size={18} /> Boston, MA</span>
          <span className="flex items-center gap-2"><Mail size={18} /> sidsharma@umass.edu</span>
          <a href="https://www.linkedin.com/in/sharma-siddharth0508" target="_blank" rel="noreferrer" className="flex items-center gap-2 hover:text-sky-400 transition-colors">
            <Linkedin size={18} /> LinkedIn
          </a>
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          <button onClick={() => document.getElementById('experience')?.scrollIntoView({ behavior: 'smooth' })} className="px-6 py-3 bg-white text-slate-950 font-semibold rounded-lg hover:bg-sky-50 transition-colors flex items-center justify-center gap-2 cursor-pointer">
            View Experience <ChevronDown size={18} />
          </button>
          <button className="px-6 py-3 bg-white/5 border border-white/10 text-white font-semibold rounded-lg hover:bg-white/10 transition-colors flex items-center justify-center gap-2 backdrop-blur-sm cursor-pointer">
            Download Resume <Download size={18} />
          </button>
        </div>
      </motion.div>
    </section>
  );
}
