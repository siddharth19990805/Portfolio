import { motion } from 'motion/react';
import { Award } from 'lucide-react';

const certs = [
  "Coursera - The 3D Printing Revolution",
  "Coursera - Introduction to Public Speaking",
  "Coursera - Cyber Security in Manufacturing",
  "Coursera - Digital Manufacturing & Design"
];

export default function Certifications() {
  return (
    <section className="w-full">
      <motion.h3
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        className="text-3xl font-bold mb-10 text-white flex items-center gap-3"
      >
        <Award className="text-sky-400" /> Certifications
      </motion.h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {certs.map((cert, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ delay: i * 0.1 }}
            className="bg-white/5 border border-white/10 backdrop-blur-md p-4 rounded-lg flex items-center gap-3 hover:bg-white/10 transition-colors"
          >
            <div className="w-2 h-2 rounded-full bg-sky-400" />
            <span className="text-slate-200">{cert}</span>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
