import { motion } from 'motion/react';
import { GraduationCap } from 'lucide-react';

const education = [
  {
    institution: "University of Massachusetts Amherst",
    degree: "Master of Science - MS, Engineering/Industrial Management",
    dates: "September 2024 - May 2026"
  },
  {
    institution: "SVKM's Narsee Monjee Institute of Management Studies (NMIMS)",
    degree: "Bachelor of Technology - BTech, Mechanical Engineering",
    dates: "2018 - 2022"
  }
];

export default function Education() {
  return (
    <section className="w-full">
      <motion.h3
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        className="text-3xl font-bold mb-10 text-white flex items-center gap-3"
      >
        <GraduationCap className="text-sky-400" /> Education
      </motion.h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {education.map((edu, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ delay: i * 0.1 }}
            className="bg-white/5 border border-white/10 backdrop-blur-md p-6 rounded-xl hover:bg-white/10 transition-colors"
          >
            <h4 className="text-lg font-semibold text-white mb-2">{edu.institution}</h4>
            <p className="text-sky-400 text-sm mb-4">{edu.degree}</p>
            <p className="text-slate-400 text-sm">{edu.dates}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
