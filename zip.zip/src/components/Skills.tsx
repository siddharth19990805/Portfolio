import { motion } from 'motion/react';
import { Code2 } from 'lucide-react';

const skills = [
  "Supply Chain Management",
  "Human Factors",
  "Global Product Management"
];

export default function Skills() {
  return (
    <section className="w-full mb-24">
      <motion.h3
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        className="text-3xl font-bold mb-10 text-white flex items-center gap-3"
      >
        <Code2 className="text-sky-400" /> Top Skills
      </motion.h3>
      <div className="flex flex-wrap gap-3">
        {skills.map((skill, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ delay: i * 0.1 }}
            className="px-4 py-2 bg-sky-500/10 border border-sky-500/20 text-sky-300 rounded-full text-sm font-medium hover:bg-sky-500/20 transition-colors"
          >
            {skill}
          </motion.div>
        ))}
      </div>
    </section>
  );
}
