import { motion } from 'motion/react';

const experiences = [
  {
    company: "NextLeap",
    role: "Product Manager Fellowship",
    dates: "March 2025 - August 2025 (6 months)",
    location: ""
  },
  {
    company: "Mastek",
    role: "Consultant L1",
    dates: "October 2023 - July 2024 (10 months)",
    location: "Ahmedabad, Gujarat, India"
  },
  {
    company: "Mastek",
    role: "Oracle HCM Associate Consultant",
    dates: "May 2022 - October 2023 (1 year 6 months)",
    location: "Ahmedabad, Gujarat, India"
  },
  {
    company: "Team Phoenix",
    role: "Head of Finance Department & Manager",
    dates: "April 2021 - July 2022 (1 year 4 months)",
    location: ""
  },
  {
    company: "Team Phoenix",
    role: "Senior Member of Manufacturing Department",
    dates: "April 2020 - April 2021 (1 year 1 month)",
    location: ""
  },
  {
    company: "Team Phoenix",
    role: "Member of Manufacturing Department",
    dates: "March 2019 - April 2020 (1 year 2 months)",
    location: ""
  },
  {
    company: "Team Raging Ashura",
    role: "Senior Vehicle Powertrain Engineer",
    dates: "April 2021 - May 2022 (1 year 2 months)",
    location: ""
  },
  {
    company: "Team Raging Ashura",
    role: "Vehicle Powertrain Engineer",
    dates: "March 2020 - March 2021 (1 year 1 month)",
    location: ""
  }
];

export default function Experience() {
  return (
    <section id="experience" className="w-full">
      <motion.h3
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        className="text-3xl font-bold mb-10 text-white"
      >
        Experience
      </motion.h3>
      <div className="relative border-l border-white/10 ml-4 md:ml-0">
        {experiences.map((exp, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ delay: i * 0.1 }}
            className="mb-10 ml-8 relative group"
          >
            <div className="absolute -left-[41px] top-1.5 w-4 h-4 rounded-full bg-sky-500 border-4 border-slate-950 group-hover:scale-125 transition-transform" />
            <div className="bg-white/5 border border-white/10 backdrop-blur-md p-6 rounded-xl hover:bg-white/10 transition-colors">
              <h4 className="text-xl font-semibold text-white">{exp.role}</h4>
              <h5 className="text-sky-400 font-medium mb-2">{exp.company}</h5>
              <div className="text-sm text-slate-400 flex flex-col sm:flex-row sm:gap-4">
                <span>{exp.dates}</span>
                {exp.location && <span className="hidden sm:inline">•</span>}
                {exp.location && <span>{exp.location}</span>}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
